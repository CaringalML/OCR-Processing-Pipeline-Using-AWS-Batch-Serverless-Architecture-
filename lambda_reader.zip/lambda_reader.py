import json
import boto3
import os
from datetime import datetime
from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event, context):
    """
    Lambda function to read processed files from DynamoDB and generate CloudFront URLs
    Triggered by API Gateway GET requests to /processed endpoint
    """
    
    # Initialize AWS clients
    dynamodb = boto3.resource('dynamodb')
    
    # Get configuration
    metadata_table_name = os.environ.get('METADATA_TABLE')
    results_table_name = os.environ.get('RESULTS_TABLE')
    cloudfront_domain = os.environ.get('CLOUDFRONT_DOMAIN')
    
    if not all([metadata_table_name, results_table_name, cloudfront_domain]):
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Configuration Error',
                'message': 'Missing required environment variables'
            })
        }
    
    try:
        # Parse query parameters
        query_params = event.get('queryStringParameters', {}) or {}
        status_filter = query_params.get('status', 'processed')
        limit = int(query_params.get('limit', '50'))
        file_id = query_params.get('fileId')
        
        metadata_table = dynamodb.Table(metadata_table_name)
        results_table = dynamodb.Table(results_table_name)
        
        # If specific file_id is requested
        if file_id:
            # Get file metadata
            metadata_response = metadata_table.query(
                KeyConditionExpression=Key('file_id').eq(file_id),
                Limit=1
            )
            
            if not metadata_response['Items']:
                return {
                    'statusCode': 404,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    'body': json.dumps({
                        'error': 'Not Found',
                        'message': f'File {file_id} not found'
                    })
                }
            
            file_metadata = metadata_response['Items'][0]
            
            # Get processing results
            results_response = results_table.get_item(
                Key={'file_id': file_id}
            )
            
            processing_result = results_response.get('Item', {})
            
            # Generate CloudFront URL
            cloudfront_url = f"https://{cloudfront_domain}/{file_metadata['s3_key']}"
            
            # Build response data with simplified types
            response_data = {
                'fileId': file_id,
                'fileName': str(file_metadata.get('file_name', '')),
                'uploadTimestamp': str(file_metadata.get('upload_timestamp', '')),
                'processingStatus': str(file_metadata.get('processing_status', '')),
                'fileSize': int(file_metadata.get('file_size', 0)),
                'contentType': str(file_metadata.get('content_type', '')),
                'cloudFrontUrl': cloudfront_url
            }
            
            # Add processing results if available
            if processing_result:
                response_data['extractedText'] = processing_result.get('extracted_text', '')
                response_data['analysis'] = {
                    'wordCount': int(processing_result.get('analysis', {}).get('word_count', 0)),
                    'characterCount': int(processing_result.get('analysis', {}).get('character_count', 0)),
                    'lineCount': int(processing_result.get('analysis', {}).get('line_count', 0)),
                    'confidence': float(processing_result.get('analysis', {}).get('confidence', 0))
                }
                response_data['processingDuration'] = str(processing_result.get('processing_duration', ''))
                
                # Add Comprehend analysis if available
                comprehend_analysis = processing_result.get('comprehend_analysis', {})
                if comprehend_analysis:
                    response_data['comprehendAnalysis'] = {
                        'language': comprehend_analysis.get('language', 'unknown'),
                        'languageScore': float(comprehend_analysis.get('languageScore', 0)),
                        'sentiment': comprehend_analysis.get('sentiment', {}),
                        'entities': comprehend_analysis.get('entities', []),
                        'keyPhrases': comprehend_analysis.get('keyPhrases', []),
                        'syntax': comprehend_analysis.get('syntax', []),
                        'processingTime': str(comprehend_analysis.get('processingTime', 0)),
                        'analyzedTextLength': int(comprehend_analysis.get('analyzedTextLength', 0)),
                        'originalTextLength': int(comprehend_analysis.get('originalTextLength', 0)),
                        'truncated': bool(comprehend_analysis.get('truncated', False))
                    }
            
        else:
            # Query files by status
            if status_filter == 'all':
                # Scan all files (less efficient but necessary for 'all')
                response = metadata_table.scan(
                    Limit=limit
                )
            else:
                # Query by status using GSI
                response = metadata_table.query(
                    IndexName='StatusIndex',
                    KeyConditionExpression=Key('processing_status').eq(status_filter),
                    Limit=limit,
                    ScanIndexForward=False  # Most recent first
                )
            
            items = response.get('Items', [])
            
            # Enrich items with CloudFront URLs and results
            processed_items = []
            for item in items:
                # Get processing results if available
                if item.get('processing_status') == 'processed':
                    results_response = results_table.get_item(
                        Key={'file_id': item['file_id']}
                    )
                    processing_result = results_response.get('Item', {})
                else:
                    processing_result = {}
                
                # Generate CloudFront URL
                cloudfront_url = f"https://{cloudfront_domain}/{item['s3_key']}"
                
                # Build item data with simplified types
                item_data = {
                    'fileId': str(item['file_id']),
                    'fileName': str(item.get('file_name', '')),
                    'uploadTimestamp': str(item.get('upload_timestamp', '')),
                    'processingStatus': str(item.get('processing_status', '')),
                    'fileSize': int(item.get('file_size', 0)),
                    'contentType': str(item.get('content_type', '')),
                    'cloudFrontUrl': cloudfront_url
                }
                
                # Add processing results if available
                if processing_result and item.get('processing_status') == 'processed':
                    item_data['extractedText'] = processing_result.get('extracted_text', '')
                    item_data['analysis'] = {
                        'wordCount': int(processing_result.get('analysis', {}).get('word_count', 0)),
                        'characterCount': int(processing_result.get('analysis', {}).get('character_count', 0)),
                        'lineCount': int(processing_result.get('analysis', {}).get('line_count', 0)),
                        'confidence': float(processing_result.get('analysis', {}).get('confidence', 0))
                    }
                    
                    # Add Comprehend analysis if available
                    comprehend_analysis = processing_result.get('comprehend_analysis', {})
                    if comprehend_analysis:
                        item_data['comprehendAnalysis'] = {
                            'language': comprehend_analysis.get('language', 'unknown'),
                            'languageScore': float(comprehend_analysis.get('languageScore', 0)),
                            'sentiment': comprehend_analysis.get('sentiment', {}),
                            'entities': comprehend_analysis.get('entities', []),
                            'keyPhrases': comprehend_analysis.get('keyPhrases', []),
                            'syntax': comprehend_analysis.get('syntax', []),
                            'processingTime': str(comprehend_analysis.get('processingTime', 0)),
                            'analyzedTextLength': int(comprehend_analysis.get('analyzedTextLength', 0)),
                            'originalTextLength': int(comprehend_analysis.get('originalTextLength', 0)),
                            'truncated': bool(comprehend_analysis.get('truncated', False))
                        }
                
                processed_items.append(item_data)
            
            response_data = {
                'files': processed_items,
                'count': len(processed_items),
                'hasMore': response.get('LastEvaluatedKey') is not None
            }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response_data)
        }
        
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Internal Server Error',
                'message': str(e)
            })
        }